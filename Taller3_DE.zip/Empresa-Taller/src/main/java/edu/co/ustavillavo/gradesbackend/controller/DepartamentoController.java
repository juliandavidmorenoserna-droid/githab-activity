package edu.co.ustavillavo.gradesbackend.controller;

import edu.co.ustavillavo.gradesbackend.model.Departamento;
import edu.co.ustavillavo.gradesbackend.service.DepartamentoService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/departamentos")
@RequiredArgsConstructor
public class DepartamentoController {

    private final DepartamentoService departamentoService;

    @PostMapping
    public Departamento guardar(@Valid @RequestBody Departamento departamento) {
        return departamentoService.guardar(departamento);
    }

    @GetMapping
    public List<Departamento> listarTodos() {
        return departamentoService.listarTodos();
    }

    @GetMapping("/{id}")
    public Departamento buscarPorId(@PathVariable Long id) {
        return departamentoService.buscarPorId(id);
    }

    @PutMapping("/{id}")
    public Departamento actualizar(@PathVariable Long id, @Valid @RequestBody Departamento departamento) {
        return departamentoService.actualizar(id, departamento);
    }

    @DeleteMapping("/{id}")
    public String eliminar(@PathVariable Long id) {
        departamentoService.eliminar(id);
        return "Departamento eliminado correctamente";
    }
}
