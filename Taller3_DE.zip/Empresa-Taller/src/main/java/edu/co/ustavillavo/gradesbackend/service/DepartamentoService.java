package edu.co.ustavillavo.gradesbackend.service;

import edu.co.ustavillavo.gradesbackend.model.Departamento;
import edu.co.ustavillavo.gradesbackend.repository.DepartamentoRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class DepartamentoService {

    private final DepartamentoRepository departamentoRepository;

    public Departamento guardar(Departamento departamento) {
        return departamentoRepository.save(departamento);
    }

    public List<Departamento> listarTodos() {
        return departamentoRepository.findAll();
    }

    public Departamento buscarPorId(Long id) {
        return departamentoRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Departamento no encontrado con id: " + id));
    }

    public Departamento actualizar(Long id, Departamento datosActualizados) {
        Departamento departamento = buscarPorId(id);
        departamento.setNombre(datosActualizados.getNombre());
        departamento.setDescripcion(datosActualizados.getDescripcion());
        return departamentoRepository.save(departamento);
    }

    public void eliminar(Long id) {
        Departamento departamento = buscarPorId(id);
        departamentoRepository.delete(departamento);
    }
}
