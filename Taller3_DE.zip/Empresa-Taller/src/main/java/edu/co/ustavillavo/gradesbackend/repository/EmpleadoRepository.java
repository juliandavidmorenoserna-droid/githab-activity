package edu.co.ustavillavo.gradesbackend.repository;

import edu.co.ustavillavo.gradesbackend.model.Empleado;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EmpleadoRepository extends JpaRepository<Empleado, Long> {
}
