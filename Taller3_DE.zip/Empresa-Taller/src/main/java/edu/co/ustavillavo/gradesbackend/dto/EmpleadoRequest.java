package edu.co.ustavillavo.gradesbackend.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EmpleadoRequest {

    private String nombre;

    private String apellido;

    private String correo;

    private Double salario;

    private Long departamentoId;
}