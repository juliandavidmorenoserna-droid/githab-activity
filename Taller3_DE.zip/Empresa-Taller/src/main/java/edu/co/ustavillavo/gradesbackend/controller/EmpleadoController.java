package edu.co.ustavillavo.gradesbackend.controller;

import edu.co.ustavillavo.gradesbackend.dto.EmpleadoRequest;
import edu.co.ustavillavo.gradesbackend.model.Empleado;
import edu.co.ustavillavo.gradesbackend.service.EmpleadoService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/empleados")
@RequiredArgsConstructor
public class EmpleadoController {

    private final EmpleadoService empleadoService;

    @PostMapping
    public Empleado guardar(@Valid @RequestBody EmpleadoRequest request) {
        return empleadoService.guardar(request);
    }

    @GetMapping
    public List<Empleado> listarTodos() {
        return empleadoService.listarTodos();
    }

    @GetMapping("/{id}")
    public Empleado buscarPorId(@PathVariable Long id) {
        return empleadoService.buscarPorId(id);
    }

    @PutMapping("/{id}")
    public Empleado actualizar(@PathVariable Long id, @Valid @RequestBody EmpleadoRequest request) {
        return empleadoService.actualizar(id, request);
    }

    @DeleteMapping("/{id}")
    public String eliminar(@PathVariable Long id) {
        empleadoService.eliminar(id);
        return "Empleado eliminado correctamente";
    }
}
