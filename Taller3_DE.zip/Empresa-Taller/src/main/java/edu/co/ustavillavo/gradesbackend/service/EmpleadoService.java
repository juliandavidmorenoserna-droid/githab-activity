package edu.co.ustavillavo.gradesbackend.service;

import edu.co.ustavillavo.gradesbackend.dto.EmpleadoRequest;
import edu.co.ustavillavo.gradesbackend.model.Departamento;
import edu.co.ustavillavo.gradesbackend.model.Empleado;
import edu.co.ustavillavo.gradesbackend.repository.DepartamentoRepository;
import edu.co.ustavillavo.gradesbackend.repository.EmpleadoRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class EmpleadoService {

    private final EmpleadoRepository empleadoRepository;
    private final DepartamentoRepository departamentoRepository;

    public Empleado guardar(EmpleadoRequest request) {
        Departamento departamento = departamentoRepository.findById(request.getDepartamentoId())
                .orElseThrow(() -> new RuntimeException("El departamento no existe"));

        Empleado empleado = new Empleado();
        empleado.setNombre(request.getNombre());
        empleado.setApellido(request.getApellido());
        empleado.setCorreo(request.getCorreo());
        empleado.setSalario(request.getSalario());
        empleado.setDepartamento(departamento);

        return empleadoRepository.save(empleado);
    }

    public List<Empleado> listarTodos() {
        return empleadoRepository.findAll();
    }

    public Empleado buscarPorId(Long id) {
        return empleadoRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Empleado no encontrado con id: " + id));
    }

    public Empleado actualizar(Long id, EmpleadoRequest request) {
        Empleado empleado = buscarPorId(id);

        Departamento departamento = departamentoRepository.findById(request.getDepartamentoId())
                .orElseThrow(() -> new RuntimeException("El departamento no existe"));

        empleado.setNombre(request.getNombre());
        empleado.setApellido(request.getApellido());
        empleado.setCorreo(request.getCorreo());
        empleado.setSalario(request.getSalario());
        empleado.setDepartamento(departamento);

        return empleadoRepository.save(empleado);
    }

    public void eliminar(Long id) {
        Empleado empleado = buscarPorId(id);
        empleadoRepository.delete(empleado);
    }
}
