package edu.co.ustavillavo.gradesbackend.repository;

import edu.co.ustavillavo.gradesbackend.model.Departamento;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DepartamentoRepository extends JpaRepository<Departamento, Long> {
}
