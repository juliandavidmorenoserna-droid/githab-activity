package edu.co.ustavillavo.gradesbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GradesBackendApplicationTests {

    @Test
    void contextLoads() {
    }
}
